#' @title Station centroid locations for each station from akgfmaps
#' @description Station centroid coordinates for each station for all surveys, as defined by the akgfmaps package. 
#' @usage data('station_coords')
#' @author Sean Rohan (sean.rohan AT noaa.gov)
#' @format A data frame with 32942 observations on the following 7 variables.
#' \describe{
#'   \item{\code{design_year}}{Design year. Year ID associated with a given value AREA_ID. This field describes the changes in the survey design over time.}
#'   \item{\code{latitude_dd}}{Latitude (decimal degrees). Latitude (one hundred thousandth of a decimal degree).}
#'   \item{\code{longitude_dd}}{Longitude (decimal degrees). Longitude (one hundred thousandth of a decimal degree).}
#'   \item{\code{srvy}}{Survey abbreviation. Abbreviated survey names. The column srvy is associated with the survey and survey_definition_id columns. Northern Bering Sea (NBS), Southeastern Bering Sea (EBS), Bering Sea Slope (BSS), Gulf of Alaska (GOA), Aleutian Islands (AI).}
#'   \item{\code{station}}{Station ID. Alpha-numeric designation for the station established in the design of a survey.}
#'   \item{\code{survey_definition_id}}{Survey ID. The survey definition ID key code is an integer that uniquely identifies a survey region/survey design. The column survey_definition_id is associated with the srvy and survey columns. Full list of survey definition IDs are in RACE_DATA.SURVEY_DEFINITIONS and in the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{geometry}}{Spatial geometry. Spatial geometry information (like points, lines, or polygons) a feature.}#'   }
#' @source https://github.com/afsc-gap-products/akgfmaps
#' @keywords station survey data
#' @examples
#' data(station_coords)
#' @details Find code to create this table in ./inst/run.R
'station_coords'
