## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----install-github, eval = FALSE---------------------------------------------
# devtools::install_github("afsc-gap-products/GAPsurvey")

## ----install-local, eval = FALSE----------------------------------------------
# # example, the user may have a different path
# install.packages('C:/Users/User/Downloads/GAPsurvey_2025.04.09.tar.gz',
#                  repos=NULL, type='source')

## ----load-packages------------------------------------------------------------
library(GAPsurvey)

## ----find-example-script, eval = FALSE----------------------------------------
# system.file("r/GAPsurvey_script.R", package = "GAPsurvey")

## ----get_catch_haul_history-learn, eval =  FALSE------------------------------
# ?get_catch_haul_history

## ----get_catch_haul_history---------------------------------------------------
## for one year and only 1 station for all species
get_catch_haul_history(
  years = 2021:2023, # optional; if you only want to see a specific year, not the last 10
  species_codes = c(21720, 21740), # optional; pacific cod and walleye pollock ONLY
  survey = "EBS", # for example
  station = "I-13") # for example

## for default 10 years and nearby stations for all species (a typical use-case)
get_catch_haul_history(
     survey = "AI",
     station = "324-73",
     grid_buffer = 3)


## ----public_data-learn, eval = FALSE------------------------------------------
# ?GAPsurvey::public_data

## ----public_data--------------------------------------------------------------
# GAPsurvey::public_data
head(GAPsurvey::public_data) # using `head()` function to see first few (6) rows of dataset 

## ----species_data-learn, eval = FALSE-----------------------------------------
# ?GAPsurvey::species_data

## ----species_data-------------------------------------------------------------
# GAPsurvey::species_data
head(GAPsurvey::species_data) # using `head()` function to see first few (6) rows of dataset 

## ----PolySpecies-learn, eval = FALSE------------------------------------------
# ?GAPsurvey::PolySpecies

## ----PolySpecies--------------------------------------------------------------
# GAPsurvey::PolySpecies
head(GAPsurvey::PolySpecies) # using `head()` function to see first few (6) rows of dataset 

## ----get_sunrise_sunset-learn, eval =  FALSE----------------------------------
# ?get_sunrise_sunset

## ----get_sunrise_sunset-------------------------------------------------------
# Find times based on lat/lon for today's date, where date is a date object
get_sunrise_sunset(chosen_date = Sys.Date(),
                   latitude = 63.3,
                   longitude = -170.5)

# Find times based on lat/lon for today's date, where date is a character
# and lat/lon in degree decimal-minutes
get_sunrise_sunset(chosen_date = "2023-06-05",
                   latitude = "63 18.0",
                   longitude = "-170 30.0")

# Find times based on a survey (AI) station's recorded lat/lon for today's date
get_sunrise_sunset(chosen_date = "2025-06-10",
                   survey = "AI",
                   station = "8-55")

# Find times based on a survey (GOA) station's recorded lat/lon for today's date
get_sunrise_sunset(chosen_date = Sys.Date(),
                   survey = "GOA",
                   station = "264-18-511") 

# Find times based on a survey (EBS) station's recorded lat/lon for today's date
get_sunrise_sunset(chosen_date = "2025-08-04",
                   survey = "EBS",
                   station = "P-31")

# Find times based on a survey (NBS) station's recorded lat/lon for today's date
get_sunrise_sunset(chosen_date = "2025-06-04",
                   survey = "NBS",
                   station = "ZZ-01")

## ----convert_ctd_btd-learn, eval =  FALSE-------------------------------------
# ?convert_ctd_btd

## ----convert_ctd_btd, eval = FALSE--------------------------------------------
# convert_ctd_btd(
#  filepath_hex = system.file(paste0("exdata/convert_ctd_btd/",
#    "2021_06_13_0003.hex"), package = "GAPsurvey"),
#  filepath_xmlcon = system.file(paste0("exdata/convert_ctd_btd/",
#    "19-8102_Deploy2021.xmlcon"), package = "GAPsurvey"),
#  latitude = 55,
#  VESSEL = 94,
#  CRUISE = 202101,
#  HAUL = 107,
#  MODEL_NUMBER = 1,
#  VERSION_NUMBER = 1,
#  SERIAL_NUMBER = 8105)

## ----convert_ted_btd-learn, eval = FALSE--------------------------------------
# ?convert_ted_btd

## ----convert_ted_btd, eval = FALSE--------------------------------------------
#  # example input files
#  readLines(system.file("exdata/convert_bvdr_btd/201901_94_0003.ted",
#    package = "GAPsurvey"))[1:5]
#  readLines(system.file("exdata/convert_bvdr_btd/201901_94_0003.tet",
#    package = "GAPsurvey"))[1:5]
#  readLines(system.file("exdata/convert_bvdr_btd/201901_94_0003.teh",
#    package = "GAPsurvey"))[1:5]
# 
#   # run function
#  convert_ted_btd(
#     VESSEL = 94,
#     CRUISE = 201901,
#     HAUL = 3,
#     MODEL_NUMBER = 123,
#     VERSION_NUMBER = 456,
#     SERIAL_NUMBER = 789,
#     path_in = system.file("exdata/convert_bvdr_btd/", package = "GAPsurvey"),
#     path_out = getwd(),
#     filename_add = "newted")
# 
#  # example output files
#  readLines(system.file("exdata/convert_bvdr_btd/HAUL0003_newted.BTD",
#    package = "GAPsurvey"))[1:5]
#  readLines(system.file("exdata/convert_bvdr_btd/HAUL0003_newted.BTH",
#    package = "GAPsurvey"))[1:5]

## ----convert_log_gps-learn, eval =  FALSE-------------------------------------
# ?convert_log_gps

## ----convert_log_gps, eval = FALSE--------------------------------------------
# # example input file
# readLines(system.file("exdata/convert_log_gps/06062017.log",
#    package = "GAPsurvey"))[1:5] # input file
# 
# # use function
# convert_log_gps(
#      VESSEL = 94,
#      CRUISE = 201901,
#      HAUL = 3,
#      DATE = "06/06/2017",
#      path_in = system.file("exdata/convert_log_gps/06062017.log",
#          package = "GAPsurvey"),
#      path_out = getwd(),
#      filename_add = "newlog")
# 
# # example output file
# readLines(system.file("exdata/convert_log_gps/HAUL0003_newlog.gps",
#    package = "GAPsurvey"))[1:5] # output file

## ----convert_bvdr_marp-learn, eval =  FALSE-----------------------------------
# ?convert_log_gps

## ----convert_bvdr_marp, eval = FALSE------------------------------------------
# # example input file
# readLines(system.file("exdata/convert_bvdr_marp/20220811-00Za.bvdr",
#   package = "GAPsurvey"))[1:5] # input file
# 
# # see what example input file looks like
# head(convert_bvdr_marp(
#   path_bvdr = system.file("exdata/convert_bvdr_marp/20220811-00Za.bvdr",
#                                   package = "GAPsurvey"),
#           verbose = TRUE), 20)
# 
# # use function
# convert_bvdr_marp(
#   path_bvdr = system.file("exdata/convert_bvdr_marp/20220811-00Za.bvdr",
#                                   package = "GAPsurvey"))
# 
# # example output file
# readLines(system.file("exdata/convert_bvdr_marp/20220811-00Za.marp",
#   package = "GAPsurvey")) # output file

